from io import BytesIO
from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt
import requests


# --------------------------------------------------
# Configuration
# --------------------------------------------------

DATA_URL = (
    "https://raw.githubusercontent.com/"
    "Vadimkin/ukrainian-air-raid-sirens-dataset/"
    "main/datasets/volunteer_data_en.csv"
)

OUTPUT_DIR = Path("outputs")
TEST_DAYS = 28
MIN_HISTORY_DAYS = 60


def load_data():
    """Download and validate the public dataset."""
    print("Downloading the latest available dataset...")

    response = requests.get(DATA_URL, timeout=60)
    response.raise_for_status()

    df = pd.read_csv(BytesIO(response.content))

    required = {"started_at", "region"}
    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"Unexpected dataset schema. Missing: {missing}. "
            f"Available columns: {list(df.columns)}"
        )

    df["started_at"] = pd.to_datetime(
        df["started_at"], utc=True, errors="coerce"
    )

    invalid = df["started_at"].isna().sum()
    df = df.dropna(subset=["started_at", "region"]).copy()

    if df.empty:
        raise ValueError("No valid alert records found.")

    print(f"Downloaded records: {len(df):,}")
    print(f"Invalid timestamps removed: {invalid:,}")
    print(f"Latest event timestamp: {df['started_at'].max()}")

    return df


def build_daily_series(df):
    """
    Count alert starts per UTC day.

    The target is the number of recorded alert starts,
    not the number of attacks or the duration of danger.
    """
    df = df.copy()
    df["date"] = df["started_at"].dt.floor("D")

    daily = df.groupby("date").size().sort_index()

    # Include days with zero recorded alert starts.
    # This assumes the source is complete for those dates;
    # completeness is not independently verified by this script.
    full_index = pd.date_range(
        start=daily.index.min(),
        end=daily.index.max(),
        freq="D",
        tz="UTC",
    )

    daily = daily.reindex(full_index, fill_value=0)
    daily.index.name = "date"
    daily.name = "alert_starts"

    return daily


def evaluate_forecasts(daily):
    """
    Evaluate rolling one-day-ahead forecasts.

    Each prediction uses only observations strictly
    earlier than its target date.
    """
    # Exclude today because it may be incomplete.
    yesterday = pd.Timestamp.now(tz="UTC").normalize() - pd.Timedelta(days=1)

    # Check that the series reaches the most recent complete UTC day.
    if daily.index.max() < yesterday:
        raise ValueError(
            f"Dataset ends on {daily.index.max().date()}, "
            f"but yesterday was {yesterday.date()}. "
            "Check data freshness before evaluating."
        )

    daily = daily.loc[:yesterday].copy()

    if len(daily) < MIN_HISTORY_DAYS + TEST_DAYS:
        raise ValueError(
            f"Not enough daily observations: {len(daily)}. "
            "Need at least "
            f"{MIN_HISTORY_DAYS + TEST_DAYS} days."
        )

    test_start = len(daily) - TEST_DAYS
    predictions = []

    for i in range(test_start, len(daily)):
        # Only dates strictly before the forecast date.
        history = daily.iloc[:i]
        actual = int(daily.iloc[i])

        # Baseline 1: repeat the previous day's count.
        naive_prediction = float(history.iloc[-1])

        # Baseline 2: mean of the previous seven days.
        weekly_prediction = float(history.iloc[-7:].mean())

        predictions.append({
            "date": daily.index[i],
            "actual": actual,
            "previous_day": naive_prediction,
            "previous_7_day_mean": weekly_prediction,
        })

    results = pd.DataFrame(predictions).set_index("date")

    metrics = {
        "Previous-day baseline": (
            results["actual"] - results["previous_day"]
        ).abs().mean(),
        "Previous-7-day mean": (
            results["actual"] - results["previous_7_day_mean"]
        ).abs().mean(),
    }

    return daily, results, metrics


def save_outputs(daily, results, metrics):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    results.to_csv(OUTPUT_DIR / "test_predictions.csv")

    pd.DataFrame(
        [{"model": name, "MAE": value}
         for name, value in metrics.items()]
    ).to_csv(OUTPUT_DIR / "metrics.csv", index=False)

    fig, ax = plt.subplots(figsize=(12, 5))

    ax.plot(
        results.index, results["actual"],
        label="Actual", marker="o"
    )
    ax.plot(
        results.index, results["previous_day"],
        label="Previous-day baseline", alpha=0.8
    )
    ax.plot(
        results.index, results["previous_7_day_mean"],
        label="Previous-7-day mean", alpha=0.8
    )

    ax.set_title("Ukraine: daily recorded alert starts")
    ax.set_xlabel("Date (UTC)")
    ax.set_ylabel("Number of alert starts")
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "forecast_evaluation.png", dpi=150)
    plt.close(fig)

    # Forecast the day after the last complete UTC day.
    last_date = daily.index[-1]
    next_date = last_date + pd.Timedelta(days=1)

    next_day_forecast = {
        "forecast_date_utc": str(next_date.date()),
        "previous_day_baseline": float(daily.iloc[-1]),
        "previous_7_day_mean": float(daily.iloc[-7:].mean()),
    }

    pd.DataFrame([next_day_forecast]).to_csv(
        OUTPUT_DIR / "next_day_forecast.csv", index=False
    )

    print("\nEvaluation period:")
    print(results.index.min().date(), "to", results.index.max().date())

    print("\nMAE (lower is better):")
    for name, value in metrics.items():
        print(f"{name}: {value:.3f}")

    print("\nNext-day forecast:")
    for name, value in next_day_forecast.items():
        print(f"{name}: {value}")

    print(f"\nFiles saved to: {OUTPUT_DIR.resolve()}")


def main():
    df = load_data()
    daily = build_daily_series(df)

    daily, results, metrics = evaluate_forecasts(daily)
    save_outputs(daily, results, metrics)


if __name__ == "__main__":
    main()
